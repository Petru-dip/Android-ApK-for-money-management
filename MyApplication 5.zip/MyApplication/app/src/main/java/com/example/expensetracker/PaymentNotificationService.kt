package com.example.expensetracker

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.Locale
import java.util.regex.Pattern

class PaymentNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        Log.d("PAYMENT_SERVICE", "Listener connected!")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        val isRevolut = sbn.packageName.equals("com.revolut.revolut", true)
                || sbn.packageName.equals("com.revolut.revolut.pay", true)
        if (!isRevolut) return

        val extras = sbn.notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = buildString {
            append(extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty())
            val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            if (big.isNotBlank()) {
                if (isNotEmpty()) append(" ")
                append(big)
            }
        }.trim()

        val payload = "$title $text"
        Log.d("PAYMENT_SERVICE", "REVOLUT raw: $payload")

        val parsed = parseRevolut(payload) ?: run {
            Log.d("PAYMENT_SERVICE", "REVOLUT: pattern not matched")
            return
        }
        Log.d("PAYMENT_SERVICE", "REVOLUT parsed: amount=${parsed.amount} currency=${parsed.currency} merchant=${parsed.merchant}")

        // Heuristică simplă pentru categorie
        val category = when {
            parsed.merchant.contains("mega", true) ||
                    parsed.merchant.contains("kaufland", true) ||
                    parsed.merchant.contains("lidl", true) ||
                    parsed.merchant.contains("carrefour", true) -> "Cumpărături"
            parsed.merchant.contains("mc", true) ||
                    parsed.merchant.contains("kfc", true) ||
                    parsed.merchant.contains("pizza", true) ||
                    parsed.merchant.contains("restaurant", true) -> "Mâncare"
            else -> ""
        }

        // Intent care DESCHIDE app-ul cu extras standardizate (EXTRA_*)
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_EXPENSE_FROM_NOTIFICATION
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_AMOUNT, parsed.amount)
            putExtra(EXTRA_CURRENCY, parsed.currency)
            putExtra(EXTRA_MERCHANT, parsed.merchant)
            putExtra(EXTRA_SOURCE, "revolut")
            if (category.isNotEmpty()) putExtra(EXTRA_CATEGORY, category)
        }

        // Best-effort: încearcă să pornești activity
        try { startActivity(openIntent) } catch (t: Throwable) {
            Log.w("PAYMENT_SERVICE", "startActivity blocked by OS, will show action notification", t)
        }

        // Fallback: notificare cu acțiune care duce în app cu aceiași extra
        InternalNotifier.showAddExpenseAction(
            context = this,
            pendingIntent = PendingIntent.getActivity(
                this, 1001, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ),
            title = "Cheltuială detectată",
            text  = "${parsed.amount} ${parsed.currency} • ${parsed.merchant}"
        )
    }

    data class RevolutParsed(val amount: Double, val currency: String, val merchant: String)

    private fun parseRevolut(payload: String): RevolutParsed? {
        val lower = payload.lowercase(Locale.ROOT)
        val pattern = Pattern.compile(
            "(?:ai plătit|paid|a fost folosit(?:.*)pentru|used for|you paid)?\\s*" +
                    "([0-9]+(?:[\\.,][0-9]{1,2})?)\\s*" +
                    "(ron|lei|eur|euro|usd|gbp)?" +
                    "(?:\\s*(?:la|at|to)\\s+([^\\n\\r\\t\\.]+))?",
            Pattern.CASE_INSENSITIVE
        )
        val m = pattern.matcher(payload)
        if (!m.find()) return null

        val rawAmount = m.group(1) ?: return null
        val currencyRaw = (m.group(2) ?: "RON").uppercase(Locale.ROOT)
            .replace("EURO", "EUR")
            .replace("LEI", "RON")
        val merchant = (m.group(3) ?: m.group(4) ?: "").ifBlank {
            val after = lower.split(" la ", " at ", " to ").getOrNull(1) ?: ""
            after.takeIf { it.isNotBlank() }?.split('\n', '\r', '.', '•')?.firstOrNull().orEmpty()
        }.trim().replace("[\\s•]+$".toRegex(), "")

        val amount = rawAmount.replace(",", ".").toDoubleOrNull() ?: return null
        return RevolutParsed(amount, currencyRaw, merchant)
    }

    companion object {
        @JvmField val ACTION_EXPENSE_FROM_NOTIFICATION =
            "com.example.expensetracker.ACTION_EXPENSE_FROM_NOTIFICATION"
        @JvmField val EXTRA_AMOUNT = "extra_amount"
        @JvmField val EXTRA_CURRENCY = "extra_currency"
        @JvmField val EXTRA_MERCHANT = "extra_merchant"
        @JvmField val EXTRA_CATEGORY = "extra_category"
        @JvmField val EXTRA_SOURCE = "extra_source"
    }
}
