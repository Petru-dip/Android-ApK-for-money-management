package com.example.expensetracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.regex.Pattern

class PaymentNotificationService : NotificationListenerService() {

    companion object {
        @JvmField val ACTION_EXPENSE_FROM_NOTIFICATION =
            "com.example.expensetracker.ACTION_EXPENSE_FROM_NOTIFICATION"
        @JvmField val EXTRA_AMOUNT   = "extra_amount"
        @JvmField val EXTRA_CURRENCY = "extra_currency"
        @JvmField val EXTRA_MERCHANT = "extra_merchant"
        @JvmField val EXTRA_SOURCE   = "extra_source"
        @JvmField val EXTRA_CATEGORY = "extra_category" // nou

        private const val PREFS = "settings"
        private const val PREF_AUTO_MODE = "auto_save_mode"

        private const val CH_AUTO_SAVE = "auto_save_feedback"
    }

    override fun onListenerConnected() {
        Log.d("PAYMENT_SERVICE", "Listener connected!")
        ensureFeedbackChannel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        // 1) Doar Revolut
        val isRevolut = sbn.packageName.equals("com.revolut.revolut", true) ||
                sbn.packageName.equals("com.revolut.revolut.pay", true)
        if (!isRevolut) return

        // 2) Extras notificare
        val extras = sbn.notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text  = buildString {
            append(extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty())
            val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            if (big.isNotBlank()) {
                if (isNotEmpty()) append(" ")
                append(big)
            }
        }.trim()

        val payload = "$title $text"
        Log.d("PAYMENT_SERVICE", "REVOLUT raw: $payload")

        // 3) Parse
        val parsed = parseRevolut(payload) ?: run {
            Log.d("PAYMENT_SERVICE", "REVOLUT: pattern not matched")
            return
        }
        Log.d("PAYMENT_SERVICE", "REVOLUT parsed: amount=${parsed.amount} currency=${parsed.currency} merchant=${parsed.merchant}")

        // 4) Auto mode?
        val autoMode = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getBoolean(PREF_AUTO_MODE, false)

        if (autoMode) {
            // --- AUTO-SAVE: Insert direct în DB, fără să deschidem app-ul ---
            val amount = if (parsed.amount != null && parsed.amount > 0.0) parsed.amount else 1.01
            val merchant = parsed.merchant.ifBlank { "Necunoscut" }
            val category = guessCategory(merchant)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getInstance(applicationContext)
                    val ex = Expense().apply {
                        this.amount = amount!!
                        this.description = merchant
                        this.date = System.currentTimeMillis()
                        this.category = category
                        this.categoryType = "PERSONAL" // poți schimba la nevoie
                        this.uid = java.util.UUID.randomUUID().toString()
                    }
                    db.expenseDao().insert(ex)
                    showAutoSavedFeedback(amount, parsed.currency ?: "RON", merchant, category)
                    Log.d("PAYMENT_SERVICE", "Auto-saved OK")
                } catch (t: Throwable) {
                    Log.e("PAYMENT_SERVICE", "Auto-saved FAILED", t)
                    // Dacă vrei, poți publica o notificare de eroare aici
                }
            }
            return
        }

        // --- UX clasic: PendingIntent care deschide aplicația la AddExpense preumplut ---
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_EXPENSE_FROM_NOTIFICATION
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            // trimitem ca double unde se poate; AddExpenseActivity oricum are fallback de string
            parsed.amount?.let { putExtra(EXTRA_AMOUNT, it) }
            putExtra(EXTRA_CURRENCY, parsed.currency)
            putExtra(EXTRA_MERCHANT, parsed.merchant)
            putExtra(EXTRA_SOURCE, "revolut")
            putExtra(EXTRA_CATEGORY, guessCategory(parsed.merchant))
        }

        // Best-effort: poate fi blocat când aplicația e în background => fallback la notificare acțiune
        try {
            startActivity(openIntent)
        } catch (t: Throwable) {
            Log.w("PAYMENT_SERVICE", "startActivity blocked; show action notification", t)
        }

        InternalNotifier.showAddExpenseAction(
            context = this,
            pendingIntent = PendingIntent.getActivity(
                this, 1001, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ),
            title = "Cheltuială detectată",
            text  = "${parsed.amount ?: "1.01"} ${parsed.currency ?: "RON"} • ${parsed.merchant}"
        )
    }

    // -------- Helpers --------

    data class RevolutParsed(val amount: Double?, val currency: String?, val merchant: String)

    private fun parseRevolut(payload: String): RevolutParsed? {
        // Exemple:
        // "Ai plătit 25,00 RON la Kaufland"
        // "You paid 25.00 RON at Kaufland"
        // "Card •1234 a fost folosit pentru 25,50 lei la Mega Image"
        val pattern = Pattern.compile(
            "(?:ai plătit|you paid|paid|a fost folosit(?:.*)pentru|used for)?\\s*" +
                    "([0-9]+(?:[\\.,][0-9]{1,2})?)?\\s*" +
                    "(ron|lei|eur|euro|usd|gbp)?\\s*" +
                    "(?:la|at|to)\\s+([^\\n\\r\\t\\.]+)",
            Pattern.CASE_INSENSITIVE
        )

        val m = pattern.matcher(payload)
        if (!m.find()) return null

        val rawAmount  = m.group(1)
        val rawCurr    = m.group(2)
        val rawMerch   = m.group(3) ?: m.group(4) ?: ""

        val amount = rawAmount?.replace(",", ".")?.toDoubleOrNull()
        val currency = rawCurr?.uppercase(Locale.ROOT)
            ?.replace("EURO", "EUR")
            ?.replace("LEI", "RON")

        val merchant = rawMerch.trim().replace("[\\s•]+$".toRegex(), "")
        return RevolutParsed(amount, currency ?: "RON", merchant)
    }

    private fun guessCategory(merchant: String): String {
        val t = merchant.lowercase(Locale.ROOT)
        return when {
            t.contains("mega") || t.contains("mega image") ||
                    t.contains("kaufland") || t.contains("lidl") ||
                    t.contains("carrefour") || t.contains("auchan") ||
                    t.contains("profi") || t.contains("penny") -> "Cumpărături"
            else -> "General"
        }
    }

    private fun ensureFeedbackChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CH_AUTO_SAVE, "Auto-save", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun showAutoSavedFeedback(amount: Double, currency: String, merchant: String, category: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val nb = NotificationCompat.Builder(this, CH_AUTO_SAVE)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("Cheltuială înregistrată")
            .setContentText(String.format(Locale.ROOT, "%.2f %s • %s • %s", amount, currency, merchant, category))
            .setAutoCancel(true)
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), nb.build())
    }
}
