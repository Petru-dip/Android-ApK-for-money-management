package com.example.expensetracker;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeUtils.applySavedTheme(this);
        super.onCreate(savedInstanceState);

        // UI minimalist: un layout vertical cu un Switch
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        SwitchMaterial swAuto = new SwitchMaterial(this);
        swAuto.setText("Auto-save din notificări");
        // ✅ Apel sigur din Java, indiferent dacă ai @JvmStatic sau nu:
        swAuto.setChecked(Settings.INSTANCE.isAutoSaveOn(this));

        swAuto.setOnCheckedChangeListener((btn, checked) -> {
            Settings.INSTANCE.setAutoSave(this, checked);
            Toast.makeText(
                    this,
                    checked ? "Auto-save activat" : "Auto-save dezactivat",
                    Toast.LENGTH_SHORT
            ).show();
        });

        root.addView(swAuto);
        setContentView(root);
    }
}
