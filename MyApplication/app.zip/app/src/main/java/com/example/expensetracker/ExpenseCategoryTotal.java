package com.example.expensetracker;
public class ExpenseCategoryTotal {
    public String category;
    public double total;
}