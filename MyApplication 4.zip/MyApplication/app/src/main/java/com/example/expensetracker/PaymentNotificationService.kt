package com.example.expensetracker

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.Locale
import java.util.regex.Pattern

class PaymentNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        Log.d("PAYMENT_SERVICE", "Listener connected!")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        // 1) Doar notificările Revolut
        val isRevolut = sbn.packageName.equals("com.revolut.revolut", true) ||
                sbn.packageName.equals("com.revolut.revolut.pay", true)
        if (!isRevolut) return

        // 2) Extras text notificare
        val extras = sbn.notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = buildString {
            append(extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty())
            val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            if (big.isNotBlank()) {
                if (isNotEmpty()) append(" ")
                append(big)
            }
        }.trim()

        val payload = "$title $text"
        Log.d("PAYMENT_SERVICE", "REVOLUT raw: $payload")

        // 3) Parse amount + currency + merchant
        val parsed = parseRevolut(payload)
        if (parsed == null) {
            Log.d("PAYMENT_SERVICE", "REVOLUT: pattern not matched")
            return
        }
        Log.d("PAYMENT_SERVICE", "REVOLUT parsed: amount=${parsed.amount} currency=${parsed.currency} merchant=${parsed.merchant}")

        // Propunere categorie din merchant
        val guessedCategory = guessCategory(parsed.merchant)

        // Intent către app cu câmpurile pre-umplute (folosește DOAR cheile EXTRA_*)
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_EXPENSE_FROM_NOTIFICATION
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_AMOUNT, parsed.amount)
            putExtra(EXTRA_CURRENCY, parsed.currency)
            putExtra(EXTRA_MERCHANT, parsed.merchant)
            putExtra(EXTRA_SOURCE, "revolut")
            if (guessedCategory.isNotEmpty()) {
                putExtra(EXTRA_CATEGORY, guessedCategory)
            }
        }

        // Best-effort: încearcă deschiderea directă (poate fi blocat de OS pe unele device-uri)
        try {
            startActivity(openIntent)
        } catch (t: Throwable) {
            Log.w("PAYMENT_SERVICE", "startActivity blocked by OS, using notification action", t)
        }

        // Oricum, publică o notificare cu acțiune care deschide aplicația cu extras
        InternalNotifier.showAddExpenseAction(
            context = this,
            pendingIntent = PendingIntent.getActivity(
                this, 1001, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ),
            title = "Cheltuială detectată",
            text = "${parsed.amount} ${parsed.currency} • ${parsed.merchant}"
        )
    }

    data class RevolutParsed(val amount: Double, val currency: String, val merchant: String)

    private fun parseRevolut(payload: String): RevolutParsed? {
        // Exemple:
        // "Ai plătit 25,00 RON la Kaufland"
        // "You paid 25.00 RON at Kaufland"
        // "Card •1234 a fost folosit pentru 25,50 lei la Mega Image"
        // "Paid 25 RON to Kaufland"
        // "25,00 RON at KAUFLAND"

        val lower = payload.lowercase(Locale.ROOT)

        val pattern = Pattern.compile(
            "(?:ai plătit|paid|a fost folosit(?:.*)pentru|used for|you paid)?\\s*" +
                    "([0-9]+(?:[\\.,][0-9]{1,2})?)\\s*" +
                    "(ron|lei|eur|euro|usd|gbp)?" +
                    "(?:\\s*(?:la|at|to)\\s+([^\\n\\r\\t\\.]+))?",
            Pattern.CASE_INSENSITIVE
        )

        val m = pattern.matcher(payload)
        if (!m.find()) return null

        val rawAmount = m.group(1) ?: return null
        val currencyRaw = (m.group(2) ?: "RON").uppercase(Locale.ROOT)
            .replace("EURO", "EUR")
            .replace("LEI", "RON")
        val merchant = (m.group(3) ?: m.group(4) ?: "").ifBlank {
            val after = lower.split(" la ", " at ", " to ").getOrNull(1) ?: ""
            after.takeIf { it.isNotBlank() }?.split('\n', '\r', '.', '•')?.firstOrNull().orEmpty()
        }.trim().replace("[\\s•]+$".toRegex(), "")

        val amount = rawAmount.replace(",", ".").toDoubleOrNull() ?: return null

        return RevolutParsed(amount = amount, currency = currencyRaw, merchant = merchant)
    }

    private fun guessCategory(merchant: String): String {
        val m = merchant.lowercase(Locale.ROOT)
        return when {
            listOf("mega image","kaufland","lidl","carrefour","profi","penny","auchan","dm","ikea")
                .any { m.contains(it) } -> "Cumpărături"
            listOf("mcdonald","kfc","subway","pizza","restaurant","food","burger","doner")
                .any { m.contains(it) } -> "Mâncare"
            listOf("uber","bolt","taxi","metro","bus","train","tarom","wizz","ryanair","blue air")
                .any { m.contains(it) } -> "Transport"
            listOf("netflix","spotify","youtube","prime","hbo","disney")
                .any { m.contains(it) } -> "Abonamente"
            else -> ""
        }
    }

    companion object {
        @JvmField val ACTION_EXPENSE_FROM_NOTIFICATION =
            "com.example.expensetracker.ACTION_EXPENSE_FROM_NOTIFICATION"

        @JvmField val EXTRA_AMOUNT   = "extra_amount"
        @JvmField val EXTRA_CURRENCY = "extra_currency"
        @JvmField val EXTRA_MERCHANT = "extra_merchant"
        @JvmField val EXTRA_SOURCE   = "extra_source"
        @JvmField val EXTRA_CATEGORY = "extra_category"   // <- nou
    }
}
