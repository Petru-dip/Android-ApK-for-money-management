package com.example.expensetracker;
public class MostExpensiveDay {
    public String day;
    public double total;
}
