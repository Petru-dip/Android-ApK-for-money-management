package com.example.expensetracker;

public class KeyValue {
    public final String key;
    public final double value;
    public KeyValue(String k, double v) { key = k; value = v; }
}
