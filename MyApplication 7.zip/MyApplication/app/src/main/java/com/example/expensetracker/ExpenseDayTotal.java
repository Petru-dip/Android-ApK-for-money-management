package com.example.expensetracker;
public class ExpenseDayTotal {
    public long dayKey;   // ziua în millis/86400000
    public double total;
}