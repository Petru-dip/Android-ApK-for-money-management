package com.example.expensetracker;

public final class IntentKeys {
    private IntentKeys() {}
    public static final String EXTRA_ID = "id"; // *** singura cheie pentru ID ***
}
