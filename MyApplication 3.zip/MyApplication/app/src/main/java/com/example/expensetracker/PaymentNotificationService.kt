package com.example.expensetracker

import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PaymentNotificationService : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.IO)

    // Aplicațiile de plată pe care le monitorizăm
    private val acceptedPackages = setOf(
        "com.revolut.revolut",                   // Revolut
        "com.google.android.apps.walletnfcrel",  // Google Wallet/Pay
        "ro.btrl.btpay",                         // BT Pay
        "ro.bcr.bcr",                            // BCR
        "com.ing.mobile",                        // ING
        "com.raiffeisen.smartmobile"             // Raiffeisen
    )

    override fun onListenerConnected() {
        super.onListenerConnected()
        android.util.Log.d("PAYMENT_SERVICE", "Listener connected!")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        try {
            val n = sbn ?: return
            val pkg = n.packageName ?: return
            if (pkg !in acceptedPackages) return

            val extras: Bundle = n.notification.extras
            val title = extras.getCharSequence("android.title")?.toString().orEmpty()
            val text = extras.getCharSequence("android.text")?.toString().orEmpty()
            val bigText = extras.getCharSequence("android.bigText")?.toString().orEmpty()
            val ticker = n.notification.tickerText?.toString().orEmpty()

            val parsed = NotificationParser.parse(
                appPkg = pkg,
                title = title,
                body = listOf(bigText, text, ticker, title)
                    .filter { it.isNotBlank() }
                    .joinToString(" • ")
            ) ?: return

            // Dacă nu ai Room încă, comentează liniile de DB și rămâi doar cu notificarea locală
            scope.launch {
                // val db = AppDatabase.getDatabase(applicationContext)
// db.transactionDao().insertAll(listOf(parsed))
// NotificationUtil.notifyPaymentDetected(applicationContext, parsed)
//
                val db = com.example.expensetracker.data.AppDatabase.getDatabase(applicationContext)
                val roomEntity = TransactionEntityRoom(
                    transactionId = parsed.transactionId,
                    amount = parsed.amount,
                    currency = parsed.currency,
                    description = parsed.description,
                    merchant = parsed.merchant,
                    bookingDate = parsed.bookingDate,
                    createdAt = parsed.createdAt,
                )
                db.transactionDao().insertAll(listOf(roomEntity))
                NotificationUtil.notifyPaymentDetected(applicationContext, parsed)

            }
        } catch (e: Exception) {
            android.util.Log.e("PAYMENT_SERVICE", "Error in onNotificationPosted", e)
        }
    }
}
